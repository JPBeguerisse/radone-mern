//auth.controller.js
const UserModel = require("../models/user.model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer"); // ✅ Import manquant
require("dotenv").config();
// const maxAge = 3 * 24 * 60 * 60 * 1000; // 3 jours
const maxAge = 1 * 60 * 60 * 1000; // 1h

module.exports.signUp = async (req, res) => {
  const { name, userName, email, password } = req.body;
  const errors = {};

  if (!name) {
    errors.name = "Le nom complet est requis.";
  }

  if (name.length < 3) {
    errors.name = "Le nom complet doit contenir 3 caractères minimum.";
  }

  if (!userName) {
    errors.userName = "Le nom de profil est requis.";
  }

  if (userName.length < 2) {
    errors.userName = "Le nom de profil doit contenir 2 caractères minimum.";
  }

  if (!email) {
    errors.email = "L'adresse email est requise.";
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    errors.email = "L'adresse email n'est pas valide.";
  }

  if (!password) {
    errors.password = "Le mot de passe est requis.";
  }

  if (password.length < 6) {
    errors.password = "Le mot de passe doit contenir au moins 6 caractères.";
  }

  try {
    const isExistEmail = await UserModel.findOne({ email });
    if (isExistEmail) {
      errors.email = "Cette adresse email existe déjà!";
    }

    const isExistUserName = await UserModel.findOne({ userName });
    if (isExistUserName) {
      errors.userName = "Ce username existe déjà!";
    }

    if (Object.keys(errors).length > 0) {
      return res.status(400).json({ errors });
    }

    // const user = await UserModel.create({
    //   name,
    //   userName,
    //   email,
    //   password,
    // });

    // res.status(201).json({ user: user.id });
    // console.log(user);
    const token = jwt.sign(
      { name, userName, email, password },
      process.env.JWT_SECRET,
      {
        expiresIn: maxAge,
      }
    );

    const confirmationUrl = `${process.env.REACT_APP_CLIENT_UR}/confirmation/${token}`;

    // Configurer le transport Nodemailer
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS,
      },
    });

    await transporter.sendMail({
      from: `"Mon App" <${process.env.MAIL_USER}>`,
      to: email,
      subject: "Confirmez votre inscription",
      html: `<p>Bonjour ${name},</p>
    <p>Merci de vous être inscrit. Cliquez sur ce lien pour activer votre compte :</p>
    <a href="${confirmationUrl}">Confirmer mon adresse e-mail</a>`,
    });

    return res.status(200).json({
      message: "Un lien de confirmation vous a été envoyé par e-mail.",
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur lors de l'inscription", error: error.message });
    console.error("Erreur lors de l'inscription:", error);
  }
};

module.exports.confirmEmail = async (req, res) => {
  try {
    const { token } = req.params; // Récupérer le token de l'URL
    const decoded = jwt.verify(token, process.env.JWT_SECRET); // Vérifier le token
    const { name, userName, email, password } = decoded; // Extraire les informations du token
    const user = await UserModel.create({ name, userName, email, password });
    return res.status(201).json({ message: "Compte activé avec succès." });
  } catch (error) {
    return res.status(400).json({ message: "Lien invalide ou expiré." });
  }
};

module.exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await UserModel.findOne({ email });

    // if (!user)
    //   return res.status(404).json({ message: "Utilisateur non trouvé" });

    // const isMatch = await bcrypt.compare(password, user.password);
    // if (!isMatch) {
    //   return res.status(400).json({ message: "Mot de passe incorrect" });
    // }

    // Si l'utilisateur n'est pas trouvé ou si le mot de passe ne correspond pas
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res
        .status(400)
        .json({ message: "Email ou mot de passe incorrect" });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: maxAge }
    );

    res.status(200).json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Erreur serveur" });
  }
};

module.exports.loginGuest = async (req, res) => {
  try {
    const guestUser = await UserModel.findOne({ isGuest: true });

    if (!guestUser)
      return res
        .status(404)
        .json({ message: "Utilisateur invité introuvable." });

    // Générer un token comme pour un login normal
    const token = jwt.sign({ id: guestUser._id }, process.env.JWT_SECRET, {
      expiresIn: "2h",
    });

    //res.status(200).json({ token, user: guestUser });
    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: "Erreur serveur", error: err.message });
  }
};

module.exports.logout = (req, res) => {
  res.status(200).json({ message: "Déconnexion réussie." });
};
